/**
 * 
 * in this package will store all the files where the objects of the maps, campaigns, characters, items
 * will be stored
 * @author fyounis
 *
 */
package soen.game.dd.files;